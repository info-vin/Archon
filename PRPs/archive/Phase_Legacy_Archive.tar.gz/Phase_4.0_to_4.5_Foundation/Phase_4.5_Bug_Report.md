# Phase 4.5 Bug & Gap Tracking Report (P4.5 缺陷與缺口追蹤表)

> **文件目的**: 集中管理 Phase 4.5 (System Institutionalization) 系統轉型過程中的已知問題、測試缺口 (Coverage Gaps) 與回歸錯誤 (Regressions)。
> **更新頻率**: 每日站會 (Daily Standup) 後更新。

---

## 📊 Summary Dashboard (摘要儀表板)

| Metric | Count | Details |
| :--- | :--- | :--- |
| **Total Issues** | 10 | Navbar RBAC, Test Data, E2E Stability. |
| **Critical Gaps** | 0 | All critical regressions resolved. |
| **Functional Bugs**| 0 | All known functional bugs fixed. |

---

## 🔍 Defect & Gap Tracking Table (缺陷追蹤詳表)

| ID | Type (類型) | Function (功能模組) | Description (問題描述) | Severity (嚴重度) | Status (狀態) | Assignee (負責人) | Trace (相關檔案) |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **BUG-013** | 🐛 Bug | **UX/RBAC** | 所有角色 (Alice, Bob, Charlie) 在 5173 登入後看到的導覽列都完全相同 (Sidebar Role Filter Fail)。 | High | 🟢 Fixed (Implemented) | Frontend | `MainLayout.tsx`, `Sidebar.tsx` |
| **BUG-014** | 🐛 Bug | **Knowledge** | Knowledge Base (Supabase Studio Tests?) 充滿測試資料，需釐清資料來源與清理機制。 | Medium | 🟢 Fixed (Implemented) | Backend/QA | `tests/backend`, `test_supabase_interaction.py` |
| **BUG-015** | 🐛 Regression | **QA/RBAC** | E2E 測試 Mock Data 過時，導致所有涉及 Sales/Marketing 頁面的測試判定為 Access Denied。 | Critical | 🟢 Fixed (Refactored) | QA | `tests/e2e/*.spec.tsx` |
| **BUG-016** | 🐛 Bug | **QA/Timing** | `task-persistence.spec.tsx` 頻繁出現 Loading 超時，需優化測試等待邏輯。 | Medium | 🟢 Fixed (Implemented) | QA | `task-persistence.spec.tsx` |
| **BUG-017** | 🐛 Regression | **QA/Setup** | `e2e.setup.tsx` 引用外部 Factory 導致 Vitest 提升錯誤 (ReferenceError)。 | Critical | 🟢 Fixed (Hoisted) | QA | `e2e.setup.tsx` |
| **BUG-018** | 🐛 Bug | **QA/Syntax** | `sales-intelligence.spec.tsx` 存在語法錯誤 (殘留字符 'n')。 | High | 🟢 Fixed (Corrected) | QA | `sales-intelligence.spec.tsx` |
| **BUG-019** | 🐛 Regression | **QA/Env** | JSDOM 不支援 `scrollIntoView`，導致測試執行中崩潰。 | Medium | 🟢 Fixed (Polyfilled) | QA | `e2e.setup.tsx` |
| **BUG-020** | 🐛 Bug | **QA/Syntax** | `prompts-management.spec.tsx` 存在賦值語法錯誤 (`=` instead of `from`)。 | Low | 🟢 Fixed (Corrected) | QA | `prompts-management.spec.tsx` |
| **BUG-021** | 🐛 Bug | **QA/UI** | `sales-nexus-closure.spec.tsx` 斷言文字 `My Potential Leads` 與實際 UI 不符。 | Low | 🟢 Fixed (Aligned) | QA | `sales-nexus-closure.spec.tsx` |
| **BUG-022** | 🐛 Bug | **QA/UI** | `PromoteForm` 測試嘗試填寫不存在的 `Vendor Name` 欄位。 | Medium | 🟢 Fixed (Aligned) | QA | `sales-nexus-closure.spec.tsx` |
| **BUG-023** | 🐛 Bug | **UI/A11y** | `MarketingPage.tsx` 的 Label 未正確關聯 Input，導致 `findByLabelText` 失敗。 | Low | 🟢 Fixed (Implemented) | Frontend | `MarketingPage.tsx` |
| **BUG-024** | 🐛 Bug | **QA/Mock** | `sales-nexus-closure` 缺少 `POST /promote` 的 MSW Handler。 | Medium | 🟢 Fixed (Implemented) | QA | `sales-nexus-closure.spec.tsx` |
| **BUG-025** | 🐛 Bug | **QA/Auth** | `TestClient` 測試中 `Depends(get_current_user)` 覆蓋失效，導致 Guardrail 測試報 403。 | High | 🟢 Fixed (Implemented) | Backend | `test_marketing_guardrails.py` |
| **BUG-026** | 🐛 Regression | **QA/E2E** | E2E 測試中 `findByText(/My Tasks/)` 因匹配導覽列且未等待 Loading 導致 "New Task" 按鈕點擊失敗。 | High | 🟢 Fixed (Implemented) | QA | `ai-teammate-workflows.spec.tsx` |
| **BUG-028** | 🐛 Bug | **QA/Env** | `api._getHeaders` 呼叫 `getSession()` 在 JSDOM/MSW 環境下偶發性掛起。 | Medium | 🟢 Fixed (Implemented) | QA | `e2e.setup.tsx` |
| **BUG-029** | 🐛 Bug | **QA/RBAC** | `admin-workflows` 因模組 Mock 狀態洩漏或重置不當導致 `isAdmin` 判定失敗。 | High | 🟢 Fixed (Implemented) | QA | `admin-workflows.spec.tsx` |
| **BUG-030** | 🐛 Bug | **QA/Logic** | `ai-teammate-workflows` 創建任務後 Dashboard 沒刷新，因 GET Mock 缺乏狀態管理。 | Medium | 🟢 Fixed (Refactored) | QA | `ai-teammate-workflows.spec.tsx` |

---

## 📝 Detailed Investigation Notes (詳細調查筆記)

### BUG-015 ~ 024: The Great E2E Institutionalization
*   ... (existing notes)

### BUG-025: Dependency Injection Overrides
*   **Root Cause**: FastAPI `Depends` 在測試中若使用傳統 `patch` 有時會因閉包綁定而失效。
*   **Solution**: 改用官方推薦的 `app.dependency_overrides` 模式，確保測試環境的 `current_user` 被 100% 注入。

### BUG-026: Semantic Heading Assertions
*   **Root Cause**: 導覽列與頁面標題文字重疊，且未等待 Dashboard 資料載入完成。
*   **Solution**: 
    1.  **Semantic Match**: 使用 `findByRole('heading', { name: /My Tasks/i })` 精確定位頁面標題。
    2.  **Role Injection**: 在測試中明確 Mock 業務角色 (Marketing/Sales)，確保標題顯示 "My Tasks" 而非 "All Tasks"。
*   **Outcome**: E2E 流程現在極其穩定，不再受權限或時序影響。

---

## ⚠️ Testing Strategy Constraints (測試策略限制)

*   **One-Shot Testing (只能測試一次)**: 
    *   由於測試環境或資源的限制（如 API Rate Limit, DB State Complexity），每個測試回合應被視為「單次機會」。
    *   **Action**: 在執行測試前，必須進行詳盡的靜態分析 (Static Analysis) 與代碼審查。測試失敗應被視為嚴重事件，需立即記錄並暫停，而非反覆重試。
    *   **Protocol**: Fail -> Log to Report -> Fix -> Verify Static -> Retry.

---

## 🛠 Fix Log (修復紀錄)

*   **2026-01-27**:
    *   **BUG-013 (RBAC)**: 完成前端權限拆分。
    *   **BUG-014 (Quality)**: 重構後端測試清理機制。
*   **2026-01-28**:
    *   **BUG-015~024 (QA Institutionalization)**: 完成 E2E 測試的全面重構，引入 `userFactory` 與 `vi.hoisted`，解決了魔術字串與提升錯誤，並修復了 JSDOM 環境缺口與 UI 語義問題。
    *   **BUG-028~030 (QA Stability)**: 驗證並修復了環境掛起 (Hanging)、Admin Mock 洩漏以及 Test Data 缺失問題，E2E 測試通過率 100%。
*   **2026-03-04 (Phase 4.6.10: 深度數據保真與儀表板優化)**:
    *   **BUG-4.6.10-01 (Backend State Transition)**: 發現 `AgentService` 中的 `agent_service.py` 舊有邏輯仍預期任務狀態為 `processing`，以及舊有代碼直接更新已不存在的 `output` 欄位。已將預期修改為正確的 `doing` 狀態，並改用專屬的 `save_agent_output` (將 LLM 結果寫入 JSONB `attachments`)。
    *   **BUG-4.6.10-02 (Test Assertion Regressions)**: 因上述 Backend 狀態與結構重構 (`task_response` 變更為包含 `{"task": {...}}` 包裝)，導致 4 個 Backend Tests 斷言失敗。已全數修正 `test_agent_service.py`, `test_agent_awakening.py` 與 `test_phase47_agent_loop.py`，讓 550 個後端測試回復至 🟢 100% 通過。
    *   **BUG-4.6.10-03 (Frontend UX)**: 5173 `TeamManagementPage` UI 因舊有 Icon (`DocumentTextIcon`) 不存在導致 Linting 錯誤，已修正為實存的 `FileTextIcon`。
    *   **Conclusion (落地實作與保真)**: 在執行 DevBot 實體化任務的過程中，驗證了只要確實排除「假資料樂觀路徑」並依靠真實的 DB 寫入與 API 查閱，系統才會暴露出真實的資料結構落差。現已達成測試全過、資料高度保真、且 DevBot 得以透過真實回應賺取 XP 的落地狀態。
