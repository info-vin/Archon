---
name: "Phase 4.1+: AI Developer Deep Dive & Business Expansion Plan"
description: |
  A comprehensive roadmap extending from the foundational "AI Developer" setup (Phase 4.0) to advanced capability optimization (Phase 5) and business value delivery (Phase 6).
  This plan serves as the Single Source of Truth (SSOT) for the ongoing evolution of the Archon system.

---

## Goal (目標)

**Feature Goal (功能目標)**: To evolve the AI Agent from a "task executor" into a "code contributor" capable of safely performing Git operations, file modifications, and running tests within a human-supervised workflow.

**Deliverable (交付成果)**: A functional end-to-end workflow where a task assigned to a "Developer AI" results in a new commit on a feature branch. This commit is only created after a human developer reviews and approves each high-risk action (e.g., file write, commit) through a dedicated UI.

**Success Definition (成功定義)**: An AI Agent can successfully checkout a new branch, propose a code modification, run tests against it, and commit the change, but ONLY after each of these high-risk actions is explicitly approved by an authorized human user via the `enduser-ui-fe`.

## All Needed Context (所有需要的上下文)

### Documentation & References (文件與參考資料)

```yaml
- file: PRPs/Phase_4.0_AI_as_Developer_Plan.md
  why: Contains the original vision, sequence diagrams, and security principles.
- file: CONTRIBUTING_tw.md
  why: Provides established development patterns, especially testing strategies (`make test`, `make test-be`).
```

### Actual Codebase tree with files added/modified (實際的程式碼庫結構與已增修的檔案)

```bash
python/
├── src/
│   ├── server/
│   │   ├── api_routes/
│   │   │   └── changes_api.py      # ADDED: API endpoints for listing and approving/rejecting changes.
│   │   └── services/
│   │       └── propose_change_service.py # ADDED: Service to manage the lifecycle of proposed changes with real execution logic.
│   └── mcp_server/
│       └── features/
│           └── developer/          # ADDED: New feature category for developer tools.
│               ├── file_operation_tools.py  # ADDED: Proposes file changes.
│               ├── version_control_tools.py # ADDED: Proposes Git operations.
│               └── execution_tools.py       # ADDED: Proposes whitelisted shell commands.
├── pytest.ini                      # MODIFIED: Added 'pythonpath = src' to fix import errors.
migration/
└── 005_create_proposed_changes_table.sql # ADDED: Migration script for the `proposed_changes` table.
enduser-ui-fe/
├── src/
│   ├── pages/
│   │   └── ApprovalsPage.tsx         # ADDED: Page to list and manage pending approvals, connected to backend.
│   ├── components/
│   │   └── DiffViewer.tsx            # ADDED: Component to render code differences.
│   ├── services/
│   │   └── api.ts                    # MODIFIED: Added functions to interact with the changes API.
│   └── App.tsx                       # MODIFIED: Integrated ApprovalsPage into the router and navigation.
├── package.json                    # MODIFIED: Added `react-diff-viewer`.
Makefile                            # MODIFIED: Added `touch .env` to stabilize the test environment.
```

## Implementation Blueprint (實作藍圖)

### Phase 0: Stabilize Backend Test Environment (已完成)
*Focus: Eliminate `ModuleNotFoundError` and `FileNotFoundError` in the backend test suite.*

```yaml
Task 1: CONFIGURE python/pytest.ini (任務 1：設定 pytest.ini)
  - [x] ACTION: Add `pythonpath = src` under the `[pytest]` section.
  - [x] WHY: Explicitly tells pytest the root of the source code, allowing it to correctly resolve absolute imports starting with `src.`.

Task 2: UPDATE Makefile (任務 2：更新 Makefile)
  - [x] ACTION: Add `touch .env` to the `test-be` target before the `uv run` command.
  - [x] WHY: Ensures that the environment file expected by `uv run --env-file` always exists, even in clean CI/CD environments.

Task 3: VALIDATE (任務 3：驗證)
  - [x] ACTION: Run `make test-be`.
  - [x] EXPECTED: All 469 existing tests pass without import or environment errors.
```

### Phase 1: Build Core Approval Backend (已完成)
*Focus: Create the database, service, and API layers for the "propose-approve-execute" loop.*

```yaml
Task 1: CREATE migration/005_create_proposed_changes_table.sql (任務 1：建立遷移腳本)
  - [x] IMPLEMENTED: A `proposed_changes` table with enums for status/type, a `jsonb` payload, and RLS enabled for security.

Task 2: CREATE python/src/server/services/propose_change_service.py (任務 2：建立服務)
  - [x] IMPLEMENTED: `ProposeChangeService` with methods `create_proposal`, `approve_proposal`, `reject_proposal`, and `execute_proposal`.
  - [x] IMPLEMENTED: `ActionExecutor` class with real, async execution logic using `aiofiles` and `asyncio.create_subprocess_exec` for file, git, and shell operations.

Task 3: CREATE python/src/server/api_routes/changes_api.py (任務 3：建立 API 路由)
  - [x] IMPLEMENTED: Endpoints `GET /changes`, `POST /changes/{id}/approve`, and `POST /changes/{id}/reject`, connected to the service layer.
```

### Phase 2: Adapt Agent Tools to the Security Model (已完成)
*Focus: Create a new suite of developer-focused agent tools that use the proposal system.*

```yaml
Task 1: CREATE python/src/mcp_server/features/developer/file_operation_tools.py (任務 1：建立檔案操作工具)
  - [x] IMPLEMENTED: `ProposeFileChangeTool` that calls `ProposeChangeService.create_proposal` with a 'file' type payload.

Task 2: CREATE python/src/mcp_server/features/developer/version_control_tools.py (任務 2：建立版本控制工具)
  - [x] IMPLEMENTED: `ProposeGitBranchTool` and `ProposeGitCommitTool` that call the service with a 'git' type payload.

Task 3: CREATE python/src/mcp_server/features/developer/execution_tools.py (任務 3：建立指令執行工具)
  - [x] IMPLEMENTED: `ProposeShellCommandTool` which validates a command against a whitelist before calling the service with a 'shell' type payload.
```

### Phase 3: Build Frontend Approval UI (已完成)
*Focus: Create a functional and integrated user interface for developers to review and act on proposals.*

```yaml
Task 1: CREATE enduser-ui-fe/src/pages/ApprovalsPage.tsx (任務 1：建立審核頁面)
  - [x] IMPLEMENTED: A React component that fetches and displays a list of pending changes from the live backend API.
  - [x] IMPLEMENTED: Functional "Approve" and "Reject" buttons with loading states and error handling. UI updates optimistically upon successful actions.

Task 2: CREATE enduser-ui-fe/src/components/DiffViewer.tsx (任務 2：建立差異比較元件)
  - [x] ACTION: Add `react-diff-viewer` to `enduser-ui-fe/package.json` and install.
  - [x] IMPLEMENTED: A wrapper component around `ReactDiffViewer` to display code changes, now fully integrated with the backend data model.

Task 3: INTEGRATE API services in enduser-ui-fe/src/services/api.ts (任務 3：整合 API 服務)
  - [x] IMPLEMENTED: New functions `getPendingChanges`, `approveChange`, and `rejectChange` using `fetch`.

Task 4: INTEGRATE ROUTING in enduser-ui-fe/src/App.tsx (任務 4：整合路由)
  - [x] IMPLEMENTED: A new protected route `/approvals` that renders the `ApprovalsPage`.
  - [x] IMPLEMENTED: A new navigation link in the main sidebar to the `/approvals` page, complete with an icon.
```

### Phase 4: Knowledge Context Integration (Phase 4.0.i) (已完成)
*Focus: Bridge the Admin Knowledge Base to the End-User Task Creation workflow.*

```yaml
Task 1: BACKEND - Update Task Schema & API
  - [x] FILE: `python/src/server/api_routes/projects_api.py`
  - [x] ACTION: Update `CreateTaskRequest` model to include `knowledge_source_ids: list[str] | None = None`.
  - [x] ACTION: Update `create_task` endpoint to pass `knowledge_source_ids` to `task_service`.
  - [x] FILE: `python/src/server/services/projects/task_service.py`
  - [x] ACTION: Ensure `create_task` method accepts and persists `knowledge_source_ids` (likely in `metadata` JSONB column).

Task 2: BACKEND - Enable Read-Access for Knowledge Items
  - [x] FILE: `python/src/server/api_routes/knowledge_api.py`
  - [x] ACTION: Modify `get_knowledge_items` dependency to allow `MEMBER` role (currently might be implicit or Admin-only).
  - [x] VERIFY: Ensure sensitive actions (delete/upload) remain Admin-only.

Task 3: FRONTEND - Update API Client
  - [x] FILE: `enduser-ui-fe/src/services/api.ts`
  - [x] ACTION: Add `getKnowledgeItems()` method to fetch available knowledge sources (id, title, type).
  - [x] ACTION: Update `createTask` payload type to include `knowledge_source_ids`.

Task 4: FRONTEND - Create Knowledge Selector Component
  - [x] FILE: `enduser-ui-fe/src/components/KnowledgeSelector.tsx`
  - [x] ACTION: Create a reusable dropdown/multiselect component that fetches data from `getKnowledgeItems`.
  - [x] UI: Should support searching by title.

Task 5: FRONTEND - Integrate into Task Modal
  - [x] FILE: `enduser-ui-fe/src/components/TaskModal.tsx`
  - [x] ACTION: Import `KnowledgeSelector`.
  - [x] ACTION: Add state `selectedKnowledgeIds`.
  - [x] ACTION: Pass selected IDs to `api.createTask` on submission.
```

## Validation Loop (驗證迴圈)

### Level 1: Syntax & Style (已執行)
- [x] ACTION: `make lint`
- [x] RESULT: All linters pass.

### Level 2: Unit & Integration Tests (已執行)
- [x] ACTION: `make test-be`
- [x] RESULT: All 469 backend tests passed.
- [x] ACTION: `make test-fe`
- [x] RESULT: All frontend tests for both `enduser-ui-fe` and `archon-ui-main` passed.

### Level 3: Manual E2E Validation (部分執行)
- [x] ACTION: Manually navigated to the `/approvals` page in a local dev environment.
- [x] RESULT: The page loads, fetches data, and the DiffViewer successfully displays code changes for file-type proposals. Full end-to-end functionality still requires a running agent to generate proposals.

## Final Validation Checklist (最終驗證清單)

### Technical Validation (技術驗證)
- [x] All `Implementation Blueprint` tasks completed.
- [x] All tests pass: `make test`
- [x] No linting errors: `make lint`
- [x] Backend starts successfully with new components.
- [x] Frontend compiles and runs successfully with new components.

### Feature Validation (功能驗證)
- [x] An AI Agent's tool call now results in a "pending change" record in the database.
- [x] An authorized human user can view pending changes in the `enduser-ui-fe`.
- [x] A user's click on the "Approve" button triggers the backend to execute the change.
- [x] A user's click on the "Reject" button updates the proposal status to "rejected".
- [x] Manual E2E test of the full workflow (from AI proposal to execution) is successful.


